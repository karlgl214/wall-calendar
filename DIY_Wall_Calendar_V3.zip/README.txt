MY WALL CALENDAR

INSTALLATION
1. Upload index.html, sync.html, wall-calendar-all-in-one-1.html, and favicon.svg together to the same website folder.
2. Open index.html in a modern browser over HTTPS.
3. Create and confirm a 4–6 digit PIN for that device.

USAGE NOTES
- Calendar data, notes, tasks, shopping items, meals, and photos are stored locally in the browser on each device.
- Use Settings > Export backup regularly, especially before clearing browser data or changing devices.
- Settings > Lock now immediately returns to the PIN screen. Closing the browser tab also ends the unlocked session.
- Phone-to-wall photo sync requires both devices to be online and to keep the sync dialog open until transfer completes.
- Live weather uses the public Open-Meteo service and requires an internet connection.
- Google Calendar is not connected in this version.

PRIVACY
The PIN is a local device lock, not an online account system. Do not use this calendar to store highly sensitive information on a shared or untrusted device.
