DIY Wall Calendar V3
Upload index.html to the existing wall-calendar GitHub repository and replace the old index.html.
This version removes temporary popups, adds working navigation, calendar view, functional to-do and shopping lists, settings, responsive phone layout, and local saving.
Next upgrade: connect shared cloud data so phone and wall screen stay synchronized, then connect Google Calendar and live Perth weather.
